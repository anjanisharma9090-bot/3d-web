import { motion } from 'framer-motion'

export default function PerformanceToggle({ perfMode, setPerfMode }) {
  const isLow = perfMode === 'low'

  return (
    <motion.button
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 1, duration: 0.5 }}
      onClick={() => setPerfMode(isLow ? 'high' : 'low')}
      className="glass fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-full px-4 py-2.5 text-xs font-mono uppercase tracking-widest text-mist hover:text-bone transition-colors"
      aria-pressed={isLow}
      title="Toggle render quality"
    >
      <span
        className={`h-2 w-2 rounded-full transition-colors ${
          isLow ? 'bg-flare' : 'bg-signal shadow-glow-cyan'
        }`}
      />
      {isLow ? 'Low Power' : 'Full Render'}
    </motion.button>
  )
}
