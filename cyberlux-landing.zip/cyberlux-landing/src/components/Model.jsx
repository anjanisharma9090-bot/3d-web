import { useRef, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import { MeshDistortMaterial, Icosahedron } from '@react-three/drei'
import * as THREE from 'three'
import { sceneState } from '../store'

// Deterministic pseudo-random orbit parameters for each shard so the
// formation looks intentional rather than noisy.
function useShardLayout(count) {
  return useMemo(() => {
    const layout = []
    for (let i = 0; i < count; i++) {
      const radius = 2.4 + Math.random() * 1.8
      layout.push({
        radius,
        speed: 0.08 + Math.random() * 0.18,
        offset: Math.random() * Math.PI * 2,
        tilt: Math.random() * Math.PI,
        scale: 0.05 + Math.random() * 0.09,
      })
    }
    return layout
  }, [count])
}

function ShardField({ count = 60 }) {
  const meshRef = useRef()
  const layout = useShardLayout(count)
  const dummy = useMemo(() => new THREE.Object3D(), [])

  useFrame((state) => {
    const t = state.clock.getElapsedTime()
    // Shards pull tight around the core in the hero, then loosen and
    // drift outward as the user scrolls into the feature section.
    const spread = 1 + sceneState.scrollProgress * 1.6

    layout.forEach((s, i) => {
      const angle = s.offset + t * s.speed
      const r = s.radius * spread
      const x = Math.cos(angle) * r
      const y = Math.sin(angle * 0.7 + s.tilt) * r * 0.5
      const z = Math.sin(angle) * r

      dummy.position.set(x, y, z)
      dummy.rotation.set(t * s.speed, t * s.speed * 0.5, 0)
      dummy.scale.setScalar(s.scale)
      dummy.updateMatrix()
      meshRef.current.setMatrixAt(i, dummy.matrix)
    })
    meshRef.current.instanceMatrix.needsUpdate = true
  })

  return (
    <instancedMesh ref={meshRef} args={[null, null, count]}>
      <octahedronGeometry args={[1, 0]} />
      <meshStandardMaterial
        color="#33e6d8"
        emissive="#7c5cff"
        emissiveIntensity={0.6}
        roughness={0.3}
        metalness={0.6}
      />
    </instancedMesh>
  )
}

export default function Model({ perfMode = 'high' }) {
  const coreRef = useRef()
  const wireRef = useRef()
  const groupRef = useRef()
  const target = useRef(new THREE.Vector3())

  useFrame((state, delta) => {
    const t = state.clock.getElapsedTime()

    // Gentle continuous self-rotation
    coreRef.current.rotation.x = t * 0.12
    coreRef.current.rotation.y = t * 0.18
    wireRef.current.rotation.x = -t * 0.08
    wireRef.current.rotation.y = t * 0.1

    // Hover / mouse response: the core tilts subtly toward the cursor
    target.current.set(sceneState.mouseX * 0.6, sceneState.mouseY * 0.4, 0)
    coreRef.current.position.x = THREE.MathUtils.lerp(coreRef.current.position.x, target.current.x * 0.3, 0.04)
    coreRef.current.position.y = THREE.MathUtils.lerp(coreRef.current.position.y, target.current.y * 0.3, 0.04)

    // Scroll-driven journey: hero (centered) -> features (left, smaller) -> cta (right, larger)
    const p = sceneState.scrollProgress
    const heroToFeatures = THREE.MathUtils.smoothstep(p, 0, 0.5)
    const featuresToCta = THREE.MathUtils.smoothstep(p, 0.5, 1)

    const xPos = THREE.MathUtils.lerp(0, -2.6, heroToFeatures) + THREE.MathUtils.lerp(0, 4.4, featuresToCta)
    const scale = THREE.MathUtils.lerp(1, 0.7, heroToFeatures) + THREE.MathUtils.lerp(0, 0.5, featuresToCta)

    groupRef.current.position.x = THREE.MathUtils.lerp(groupRef.current.position.x, xPos, 0.06)
    groupRef.current.scale.setScalar(THREE.MathUtils.lerp(groupRef.current.scale.x, scale, 0.06))
  })

  return (
    <group ref={groupRef}>
      <Icosahedron ref={coreRef} args={[1.15, 4]}>
        <MeshDistortMaterial
          color="#7c5cff"
          roughness={0.15}
          metalness={0.85}
          distort={0.35}
          speed={1.4}
          envMapIntensity={1.2}
        />
      </Icosahedron>

      <Icosahedron ref={wireRef} args={[1.55, 1]}>
        <meshBasicMaterial color="#33e6d8" wireframe transparent opacity={0.25} />
      </Icosahedron>

      <ShardField key={perfMode} count={perfMode === 'low' ? 24 : 60} />
    </group>
  )
}
