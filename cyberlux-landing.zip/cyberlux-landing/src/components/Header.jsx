import { motion } from 'framer-motion'

const links = ['Core', 'System', 'Access']

export default function Header() {
  return (
    <motion.header
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
      className="fixed top-0 inset-x-0 z-50 flex justify-center px-6 pt-5"
    >
      <nav className="glass w-full max-w-5xl rounded-full px-6 py-3 flex items-center justify-between">
        <span className="font-display font-semibold tracking-[0.2em] text-sm text-bone">
          NO<span className="text-ion">VA</span>
        </span>

        <ul className="hidden sm:flex items-center gap-8">
          {links.map((link) => (
            <li key={link}>
              <a
                href={`#${link.toLowerCase()}`}
                className="relative font-mono text-xs uppercase tracking-widest text-mist transition-colors hover:text-bone group"
              >
                {link}
                <span className="absolute -bottom-1 left-0 h-px w-0 bg-signal transition-all duration-300 group-hover:w-full" />
              </a>
            </li>
          ))}
        </ul>

        <a
          href="#access"
          className="font-mono text-xs uppercase tracking-widest px-4 py-2 rounded-full border border-ion/40 text-bone hover:border-signal hover:shadow-glow-cyan transition-all duration-300"
        >
          Request Access
        </a>
      </nav>
    </motion.header>
  )
}
