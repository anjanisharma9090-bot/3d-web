import { motion } from 'framer-motion'

export default function FeatureCard({ index, title, description, metric }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-80px' }}
      transition={{ duration: 0.6, delay: index * 0.12, ease: [0.16, 1, 0.3, 1] }}
      whileHover={{ scale: 1.03, y: -4 }}
      className="glass relative rounded-2xl p-7 overflow-hidden group cursor-default transition-shadow duration-300 hover:shadow-glow"
    >
      <div className="absolute inset-0 rounded-2xl border border-transparent group-hover:border-ion/50 transition-colors duration-300 pointer-events-none" />

      <span className="font-mono text-xs text-signal tracking-widest">{metric}</span>
      <h3 className="font-display text-xl text-bone mt-4 mb-2">{title}</h3>
      <p className="text-sm text-mist leading-relaxed">{description}</p>
    </motion.div>
  )
}
