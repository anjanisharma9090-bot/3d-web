import { useRef, useEffect } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Environment, ContactShadows } from '@react-three/drei'
import * as THREE from 'three'
import Model from './Model'
import { sceneState } from '../store'

function MouseLight() {
  const lightRef = useRef()
  useFrame(() => {
    if (!lightRef.current) return
    const targetX = sceneState.mouseX * 4
    const targetY = sceneState.mouseY * 3
    lightRef.current.position.x = THREE.MathUtils.lerp(lightRef.current.position.x, targetX, 0.08)
    lightRef.current.position.y = THREE.MathUtils.lerp(lightRef.current.position.y, targetY, 0.08)
  })
  return <pointLight ref={lightRef} position={[0, 0, 3]} intensity={12} color="#7c5cff" distance={9} decay={2} />
}

function CameraRig() {
  const { camera, size } = useThree()
  const basePos = useRef(new THREE.Vector3(0, 0, 6.5))

  // Responsive distance: pull the camera back on narrow viewports so the
  // core and its shard field stay fully in frame instead of being cropped.
  const mobileOffset = size.width < 640 ? 2.4 : size.width < 1024 ? 1 : 0

  useFrame(() => {
    const p = sceneState.scrollProgress

    // Scroll-driven camera arc across the three sections
    const targetZ =
      mobileOffset +
      THREE.MathUtils.lerp(6.5, 8.2, THREE.MathUtils.smoothstep(p, 0, 0.5)) -
      THREE.MathUtils.lerp(0, 1.4, THREE.MathUtils.smoothstep(p, 0.5, 1))
    const targetY = THREE.MathUtils.lerp(0, 0.6, THREE.MathUtils.smoothstep(p, 0, 1))

    // Mouse parallax tilt, layered on top of the scroll position
    const parallaxX = sceneState.mouseX * 0.6
    const parallaxY = sceneState.mouseY * 0.35

    basePos.current.z = THREE.MathUtils.lerp(basePos.current.z, targetZ, 0.04)
    basePos.current.y = THREE.MathUtils.lerp(basePos.current.y, targetY, 0.04)

    camera.position.x = THREE.MathUtils.lerp(camera.position.x, parallaxX, 0.06)
    camera.position.y = THREE.MathUtils.lerp(camera.position.y, basePos.current.y + parallaxY, 0.06)
    camera.position.z = basePos.current.z

    camera.lookAt(0, 0, 0)
  })

  return null
}

function PointerTracker() {
  useEffect(() => {
    const handleMove = (e) => {
      sceneState.mouseX = (e.clientX / window.innerWidth) * 2 - 1
      sceneState.mouseY = -((e.clientY / window.innerHeight) * 2 - 1)
    }
    window.addEventListener('pointermove', handleMove)
    return () => window.removeEventListener('pointermove', handleMove)
  }, [])
  return null
}

export default function Scene({ perfMode }) {
  return (
    <Canvas
      dpr={perfMode === 'low' ? 1 : [1, 2]}
      shadows={perfMode !== 'low'}
      gl={{ antialias: perfMode !== 'low', powerPreference: 'high-performance' }}
      camera={{ position: [0, 0, 6.5], fov: 45 }}
      className="!fixed inset-0"
    >
      <color attach="background" args={['#0a0a0f']} />
      <fog attach="fog" args={['#0a0a0f', 8, 16]} />

      <ambientLight intensity={0.25} />
      <directionalLight
        position={[4, 6, 4]}
        intensity={0.6}
        castShadow={perfMode !== 'low'}
        shadow-mapSize={[1024, 1024]}
      />
      <MouseLight />

      <Model perfMode={perfMode} />

      {perfMode !== 'low' && (
        <ContactShadows position={[0, -2.2, 0]} opacity={0.35} scale={10} blur={2.5} far={4} color="#7c5cff" />
      )}

      <Environment preset="city" />

      <CameraRig />
      <PointerTracker />
    </Canvas>
  )
}
