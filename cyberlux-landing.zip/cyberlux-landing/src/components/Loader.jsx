export default function Loader() {
  return (
    <div className="fixed inset-0 z-40 flex flex-col items-center justify-center gap-4 bg-void">
      <div className="loader-ring" />
      <span className="font-mono text-xs tracking-widest text-mist uppercase">Assembling core</span>
    </div>
  )
}
