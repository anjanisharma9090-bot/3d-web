import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Header from './Header'
import FeatureCard from './FeatureCard'
import { sceneState } from '../store'

gsap.registerPlugin(ScrollTrigger)

const features = [
  {
    metric: '01 · Latency',
    title: 'Sub-millisecond routing',
    description:
      'The core resolves each request against a live shard graph, choosing the shortest path before your query finishes loading.',
  },
  {
    metric: '02 · Coherence',
    title: 'Self-healing formation',
    description:
      'When a shard drops out, the surrounding field re-balances instantly — no orchestration layer, no downtime.',
  },
  {
    metric: '03 · Footprint',
    title: 'Runs at the edge',
    description:
      'A distilled build of the core fits on-device, so the same system scales from a wearable to a data hall.',
  },
]

export default function Overlay() {
  const containerRef = useRef(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: containerRef.current,
        start: 'top top',
        end: 'bottom bottom',
        scrub: 0.6,
        onUpdate: (self) => {
          sceneState.scrollProgress = self.progress
          sceneState.section = self.progress < 0.4 ? 0 : self.progress < 0.75 ? 1 : 2
        },
      })
    }, containerRef)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={containerRef} className="relative z-10">
      <Header />

      {/* HERO */}
      <section id="hero" className="min-h-screen flex flex-col justify-center px-6 sm:px-12 lg:px-24">
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="font-mono text-xs uppercase tracking-[0.35em] text-signal mb-5"
        >
          Distributed Intelligence · Live
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="font-display font-semibold text-5xl sm:text-6xl lg:text-7xl max-w-3xl leading-[1.05] text-bone"
        >
          A core that reshapes itself around every query.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.55, duration: 0.6 }}
          className="mt-6 max-w-xl text-base sm:text-lg text-mist leading-relaxed"
        >
          NOVA is a distributed inference fabric that fractures, re-forms, and routes
          around failure in real time. Watch the field respond as you move.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.6 }}
          className="mt-10"
        >
          <a
            href="#access"
            className="glass inline-flex items-center gap-3 rounded-full pl-6 pr-2 py-2 font-display text-sm text-bone animate-pulseGlow hover:shadow-glow transition-shadow duration-300"
          >
            Enter the system
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-ion text-void">→</span>
          </a>
        </motion.div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-mist">
          <span className="font-mono text-[10px] uppercase tracking-widest">Scroll</span>
          <div className="h-8 w-px bg-gradient-to-b from-mist to-transparent" />
        </div>
      </section>

      {/* FEATURES */}
      <section id="system" className="min-h-screen flex flex-col justify-center px-6 sm:px-12 lg:px-24 py-24">
        <div className="max-w-xl mb-14">
          <p className="font-mono text-xs uppercase tracking-[0.35em] text-signal mb-4">System</p>
          <h2 className="font-display font-semibold text-3xl sm:text-4xl text-bone">
            Built to fracture on purpose.
          </h2>
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 max-w-4xl">
          {features.map((f, i) => (
            <FeatureCard key={f.title} index={i} {...f} />
          ))}
        </div>
      </section>

      {/* CTA */}
      <section
        id="access"
        className="min-h-screen flex flex-col justify-center items-start px-6 sm:px-12 lg:px-24 py-24"
      >
        <div className="max-w-xl">
          <p className="font-mono text-xs uppercase tracking-[0.35em] text-signal mb-4">Access</p>
          <h2 className="font-display font-semibold text-4xl sm:text-5xl text-bone leading-tight mb-6">
            Bring your workload to the core.
          </h2>
          <p className="text-base text-mist leading-relaxed mb-9 max-w-md">
            Limited onboarding slots open this quarter. Tell us what you're running and
            we'll route you to a shard cluster within 48 hours.
          </p>

          <motion.a
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.97 }}
            href="mailto:access@nova.system"
            className="glass inline-flex items-center gap-3 rounded-full pl-6 pr-2 py-2 font-display text-sm text-bone animate-pulseGlow hover:shadow-glow transition-shadow duration-300"
          >
            Request access
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-signal text-void">→</span>
          </motion.a>
        </div>

        <footer className="mt-32 w-full flex flex-col sm:flex-row justify-between gap-4 border-t border-white/5 pt-6 text-xs text-mist font-mono">
          <span>© {new Date().getFullYear()} NOVA Systems</span>
          <span>Rendered in real time — no two sessions alike</span>
        </footer>
      </section>
    </div>
  )
}
