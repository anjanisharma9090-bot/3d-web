import { Suspense, useState, useEffect } from 'react'
import Scene from './components/Scene'
import Overlay from './components/Overlay'
import Loader from './components/Loader'
import PerformanceToggle from './components/PerformanceToggle'
import { sceneState } from './store'

export default function App() {
  const [perfMode, setPerfMode] = useState('high')

  // Auto-drop to low power on small / likely low-end screens so mobile
  // stays smooth without the user needing to find the toggle.
  useEffect(() => {
    if (window.innerWidth < 640 || navigator.hardwareConcurrency <= 4) {
      setPerfMode('low')
    }
  }, [])

  useEffect(() => {
    sceneState.perfMode = perfMode
  }, [perfMode])

  return (
    <div className="relative min-h-screen bg-void">
      <Suspense fallback={<Loader />}>
        <Scene perfMode={perfMode} />
      </Suspense>

      <Overlay />

      <PerformanceToggle perfMode={perfMode} setPerfMode={setPerfMode} />
    </div>
  )
}
