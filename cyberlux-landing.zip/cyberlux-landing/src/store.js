// A tiny mutable store. GSAP ScrollTrigger writes to it on scroll,
// the R3F render loop reads it every frame via useFrame.
// Keeping this outside React state avoids re-rendering the component
// tree on every scroll pixel / mouse pixel, which is what keeps the
// scene at 60fps.
export const sceneState = {
  scrollProgress: 0, // 0 -> 1 across the whole page
  section: 0, // 0 = hero, 1 = features, 2 = cta
  mouseX: 0, // normalized -1 -> 1
  mouseY: 0, // normalized -1 -> 1
  perfMode: 'high', // 'high' | 'low'
}
