# NOVA — Cyber-Lux 3D Landing Page

An interactive WebGL landing page built with React + Three.js (via `@react-three/fiber`
and `@react-three/drei`), Tailwind CSS, Framer Motion, and GSAP ScrollTrigger.

**Signature element:** the *Fractured Core* — a distorted, reflective icosahedron
wrapped in a wireframe hologram twin, orbited by an instanced field of glowing
shards that pull tight around the core in the hero and drift apart as you scroll
into the feature section, then reform for the CTA.

## 1. Setup

```bash
# create the project folder (or unzip the provided files) then:
cd cyberlux-landing
npm install
```

## 2. Run locally

```bash
npm run dev
```

Open the printed local URL (typically `http://localhost:5173`).

## 3. Build for production

```bash
npm run build
npm run preview   # sanity-check the production build locally
```

## Project structure

```
cyberlux-landing/
├── index.html
├── package.json
├── tailwind.config.js         # design tokens: color, type, glow shadows
├── postcss.config.js
├── vite.config.js
└── src/
    ├── main.jsx                # React root
    ├── App.jsx                 # lifts perf-mode state, Suspense boundary
    ├── index.css                # Tailwind directives + base/reset styles
    ├── store.js                 # mutable scroll/pointer store (perf pattern, see below)
    └── components/
        ├── Scene.jsx             # Canvas, lights, mouse-follow light, camera rig
        ├── Model.jsx             # the Fractured Core + shard field
        ├── Overlay.jsx           # hero / features / CTA sections + ScrollTrigger wiring
        ├── Header.jsx            # glass navbar
        ├── FeatureCard.jsx       # feature grid card
        ├── PerformanceToggle.jsx # floating low-power toggle
        └── Loader.jsx            # Suspense fallback spinner
```

## How the interactions work

- **Mouse parallax & hover**: `PointerTracker` (in `Scene.jsx`) writes normalized
  mouse coordinates into a plain mutable object (`src/store.js`), not React state.
  `useFrame` loops in `CameraRig`, `MouseLight`, and `Model` read that object every
  frame and `lerp` toward it. This is deliberate — writing mouse/scroll position
  into React state would re-render the component tree on every pixel of movement;
  reading a ref/plain object inside `useFrame` keeps everything on the WebGL
  render loop and off React's reconciler, which is what keeps this at 60fps.
- **Scroll sync**: `Overlay.jsx` creates a single `ScrollTrigger` spanning the
  whole page (`start: 'top top'`, `end: 'bottom bottom'`) and writes
  `scrollProgress` (0→1) into the same store on every scroll tick. `Model.jsx`
  and `Scene.jsx` use that progress with `THREE.MathUtils.smoothstep` to move the
  core and camera between three arrangements (hero / features / CTA) — no
  React re-render involved, so scrubbing stays smooth even on trackpads.
- **Performance toggle**: the floating button in the bottom-right flips
  `perfMode` between `'high'` and `'low'`. This is real React state (it's a rare
  user action, not a per-frame one) and controls Canvas `dpr`, antialiasing,
  shadow casting, contact shadows, and the shard-field instance count (60 → 24).
- **Mobile**: viewport width and `navigator.hardwareConcurrency` are checked
  once on mount to default constrained devices into low-power mode, and the
  camera rig adds a distance offset on narrow viewports so the model doesn't
  get cropped.

## Customizing

- **Palette / type**: edit `tailwind.config.js` → `theme.extend.colors` and
  `fontFamily`. The whole page derives from `void`, `ion`, `signal`, `flare`,
  `mist`, `bone`.
- **Copy**: all headline/body copy lives in `Overlay.jsx`.
- **Core geometry**: swap `Icosahedron` in `Model.jsx` for `TorusKnot`, `Sphere`,
  or any drei/three geometry — the distort material and scroll logic don't care
  what shape they're wrapping.
- **Shard count / spread**: tune `count` and the `radius`/`spread` math in
  `ShardField` inside `Model.jsx`.

## Notes on dependency versions

`@react-three/fiber` v8 + `@react-three/drei` v9 are pinned because they target
React 18 (the versions used here). If you upgrade to React 19, move to
`@react-three/fiber` v9 / `@react-three/drei` v10 and check drei's migration
notes for renamed props.
