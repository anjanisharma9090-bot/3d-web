/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        void: '#0a0a0f',
        panel: 'rgba(255,255,255,0.04)',
        ion: '#7c5cff',
        signal: '#33e6d8',
        flare: '#ff3d9a',
        mist: '#8b8b9a',
        bone: '#f2f2f7',
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      boxShadow: {
        glow: '0 0 40px rgba(124, 92, 255, 0.35)',
        'glow-cyan': '0 0 40px rgba(51, 230, 216, 0.3)',
      },
      backdropBlur: {
        xs: '2px',
      },
      keyframes: {
        pulseGlow: {
          '0%, 100%': { boxShadow: '0 0 20px rgba(124, 92, 255, 0.35)' },
          '50%': { boxShadow: '0 0 45px rgba(124, 92, 255, 0.65)' },
        },
      },
      animation: {
        pulseGlow: 'pulseGlow 2.8s ease-in-out infinite',
      },
    },
  },
  plugins: [],
}
